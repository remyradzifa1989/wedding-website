<?php
// ============================================================
//  Tetapan sambungan pangkalan data (MySQL / phpMyAdmin)
//  Tukar nilai di bawah jika perlu. Untuk XAMPP default,
//  biasanya: host=localhost, user=root, password=(kosong)
// ============================================================

$DB_HOST = 'localhost';
$DB_USER = 'root';
$DB_PASS = '';
$DB_NAME = 'wedding_rsvp';

// --- Jangan ubah di bawah ini ---
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }

$conn = @new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);
if ($conn->connect_error) {
    http_response_code(500);
    echo json_encode(['error' => 'Sambungan pangkalan data gagal: ' . $conn->connect_error]);
    exit;
}
$conn->set_charset('utf8mb4');
