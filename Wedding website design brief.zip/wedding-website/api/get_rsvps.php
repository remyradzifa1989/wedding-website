<?php
// Ambil semua RSVP (untuk papan pemuka admin)
require __DIR__ . '/config.php';

$res = $conn->query('SELECT id, nama, phone, kehadiran, category, seats, bilangan, ucapan, ts FROM rsvps ORDER BY ts ASC');
$out = [];
if ($res) {
    while ($row = $res->fetch_assoc()) {
        $seats = json_decode($row['seats'], true);
        $row['seats'] = is_array($seats) ? $seats : [];
        $row['bilangan'] = intval($row['bilangan']);
        $row['ts'] = intval($row['ts']);
        $out[] = $row;
    }
}
echo json_encode($out, JSON_UNESCAPED_UNICODE);
$conn->close();
