<?php
// Padam semua RSVP (butang "Padam Semua" di papan pemuka)
require __DIR__ . '/config.php';

if ($conn->query('TRUNCATE TABLE rsvps')) {
    echo json_encode(['ok' => true]);
} else {
    http_response_code(500);
    echo json_encode(['error' => $conn->error]);
}
$conn->close();
