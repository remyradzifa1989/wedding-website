<?php
// Simpan RSVP baharu ke pangkalan data
require __DIR__ . '/config.php';

$raw = file_get_contents('php://input');
$d = json_decode($raw, true);

if (!$d || empty($d['nama'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Data tidak lengkap.']);
    exit;
}

$id        = isset($d['id']) ? $d['id'] : ('WD' . time());
$nama      = isset($d['nama']) ? $d['nama'] : '';
$phone     = isset($d['phone']) ? $d['phone'] : '';
$kehadiran = isset($d['kehadiran']) ? $d['kehadiran'] : 'hadir';
$category  = isset($d['category']) ? $d['category'] : '-';
$seats     = isset($d['seats']) ? json_encode($d['seats'], JSON_UNESCAPED_UNICODE) : '[]';
$bilangan  = isset($d['bilangan']) ? intval($d['bilangan']) : 0;
$ucapan    = isset($d['ucapan']) ? $d['ucapan'] : '';
$ts        = isset($d['ts']) ? intval($d['ts']) : (time() * 1000);

$stmt = $conn->prepare(
    'INSERT INTO rsvps (id, nama, phone, kehadiran, category, seats, bilangan, ucapan, ts)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
     ON DUPLICATE KEY UPDATE nama=VALUES(nama), phone=VALUES(phone), kehadiran=VALUES(kehadiran),
       category=VALUES(category), seats=VALUES(seats), bilangan=VALUES(bilangan), ucapan=VALUES(ucapan)'
);
$stmt->bind_param('ssssssisi', $id, $nama, $phone, $kehadiran, $category, $seats, $bilangan, $ucapan, $ts);

if ($stmt->execute()) {
    echo json_encode(['ok' => true, 'id' => $id]);
} else {
    http_response_code(500);
    echo json_encode(['error' => $stmt->error]);
}
$stmt->close();
$conn->close();
