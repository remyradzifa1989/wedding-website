-- =====================================================================
--  PANGKALAN DATA WEBSITE KAHWIN — Farid & Amy
--  Import fail ini melalui phpMyAdmin (tab "Import")
--  atau jalankan di tab "SQL".
-- =====================================================================

CREATE DATABASE IF NOT EXISTS `wedding_rsvp`
  DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE `wedding_rsvp`;

CREATE TABLE IF NOT EXISTS `rsvps` (
  `id`         VARCHAR(32)  NOT NULL,
  `nama`       VARCHAR(150) NOT NULL,
  `phone`      VARCHAR(40)  DEFAULT NULL,
  `kehadiran`  VARCHAR(20)  DEFAULT 'hadir',
  `category`   VARCHAR(80)  DEFAULT '-',
  `seats`      TEXT         DEFAULT NULL,        -- disimpan sebagai JSON, cth: ["M3/K1","M3/K2"]
  `bilangan`   INT          DEFAULT 0,
  `ucapan`     TEXT         DEFAULT NULL,
  `ts`         BIGINT       DEFAULT NULL,        -- masa hantar (epoch milisaat)
  `created_at` TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
